#ifndef _NPE_IMAGE_H_
#define _NPE_IMAGE_H_

#include "net/npe/image/PixelFormat.h"
#include "net/npe/image/PixelImage.h"

#include "net/npe/image/dds/DdsImage.h"
#include "net/npe/image/dds/DdsReader.h"

#include "net/npe/image/psd/PsdChannel.h"
#include "net/npe/image/psd/PsdColorMode.h"
#include "net/npe/image/psd/PsdDecorder.h"
#include "net/npe/image/psd/PsdImage.h"
#include "net/npe/image/psd/PsdLayer.h"

#include "net/npe/image/tga/TgaImage.h"
#include "net/npe/image/tga/TgaReader.h"
#include "net/npe/image/tga/TgaWriter.h"

#include "net/npe/image/util/ImageReader.h"
#include "net/npe/image/util/ImageType.h"
#include "net/npe/image/util/ImageWriter.h"

inline void npeInitializeImageLibrary() {
  NetNpeImagePixelFormat_initialize();
  NetNpeImagePixelImage_initialize();
  NetNpeImageDdsDdsImage_initialize();
  NetNpeImageDdsDdsReader_initialize();
  NetNpeImagePsdPsdChannel_initialize();
  NetNpeImagePsdPsdColorModeEnum_initialize();
  NetNpeImagePsdPsdDecorder_initialize();
  NetNpeImagePsdPsdImage_initialize();
  NetNpeImagePsdPsdLayer_initialize();
  NetNpeImageTgaTgaImage_initialize();
  NetNpeImageTgaTgaReader_initialize();
  NetNpeImageTgaTgaWriter_initialize();
  NetNpeImageUtilImageReader_initialize();
  NetNpeImageUtilImageTypeEnum_initialize();
  NetNpeImageUtilImageWriter_initialize();
}

#endif /* _NPE_IMAGE_H_ */
