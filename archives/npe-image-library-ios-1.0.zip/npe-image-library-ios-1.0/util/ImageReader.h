//
//  ImageReader.h
//  DDSImageViewer_iOS
//
//  Created by Sasaki Kenji on 2015/07/20.
//  Copyright (c) 2015年 Sasaki Kenji. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "npeimage.h"

@interface ImageReader : NSObject

+ (NetNpeImagePixelImage *)read:(NSString *)path;
+ (NetNpeImagePixelImage *)read:(NSString *)path withFormat:(NetNpeImagePixelFormat *)format;

+ (NetNpeImagePixelImage *)createPixelImage:(UIImage *)image;

+ (UIImage *)createUIImage:(NSString *)path;
+ (UIImage *)createUIImageFromPixelImage:(NetNpeImagePixelImage *)image;
+ (CGImageRef)createCGImage:(NetNpeImagePixelImage *)image;

+ (void *)allocateMemory:(size_t)size;
+ (void)freeMemory:(void *)memory;

@end
